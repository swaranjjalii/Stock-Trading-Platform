import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Stock {
    String symbol;
    String name;
    double price;

    Stock(String symbol, String name, double price) {
        this.symbol = symbol;
        this.name = name;
        this.price = price;
    }
}

class Portfolio {
    Map<String, Integer> holdings;
    double cash;

    Portfolio(double initialCash) {
        this.holdings = new HashMap<>();
        this.cash = initialCash;
    }

    void buyStock(Stock stock, int quantity) {
        double totalCost = stock.price * quantity;
        if (cash >= totalCost) {
            holdings.put(stock.symbol, holdings.getOrDefault(stock.symbol, 0) + quantity);
            cash -= totalCost;
            System.out.println("Bought " + quantity + " shares of " + stock.symbol);
        } else {
            System.out.println("Insufficient funds to buy " + quantity + " shares of " + stock.symbol);
        }
    }

    void sellStock(Stock stock, int quantity) {
        int currentHolding = holdings.getOrDefault(stock.symbol, 0);
        if (currentHolding >= quantity) {
            holdings.put(stock.symbol, currentHolding - quantity);
            cash += stock.price * quantity;
            System.out.println("Sold " + quantity + " shares of " + stock.symbol);
        } else {
            System.out.println("Insufficient shares to sell " + quantity + " shares of " + stock.symbol);
        }
    }

    void displayPortfolio(Map<String, Stock> market) {
        System.out.println("Cash: $" + cash);
        System.out.println("Holdings:");
        for (Map.Entry<String, Integer> entry : holdings.entrySet()) {
            Stock stock = market.get(entry.getKey());
            System.out.println(stock.symbol + " (" + stock.name + "): " + entry.getValue() + " shares @ $" + stock.price + " each");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Map<String, Stock> market = new HashMap<>();
        market.put("AAPL", new Stock("AAPL", "Apple Inc.", 150.00));
        market.put("GOOGL", new Stock("GOOGL", "Alphabet Inc.", 2800.00));
        market.put("AMZN", new Stock("AMZN", "Amazon.com Inc.", 3400.00));

        Portfolio portfolio = new Portfolio(10000.00);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nStock Trading Platform");
            System.out.println("1. View Market Data");
            System.out.println("2. Buy Stock");
            System.out.println("3. Sell Stock");
            System.out.println("4. View Portfolio");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Market Data:");
                    for (Stock stock : market.values()) {
                        System.out.println(stock.symbol + " (" + stock.name + "): $" + stock.price);
                    }
                    break;
                case 2:
                    System.out.print("Enter stock symbol: ");
                    String buySymbol = scanner.next();
                    Stock buyStock = market.get(buySymbol.toUpperCase());
                    if (buyStock != null) {
                        System.out.print("Enter quantity to buy: ");
                        int buyQuantity = scanner.nextInt();
                        portfolio.buyStock(buyStock, buyQuantity);
                    } else {
                        System.out.println("Invalid stock symbol.");
                    }
                    break;
                case 3:
                    System.out.print("Enter stock symbol: ");
                    String sellSymbol = scanner.next();
                    Stock sellStock = market.get(sellSymbol.toUpperCase());
                    if (sellStock != null) {
                        System.out.print("Enter quantity to sell: ");
                        int sellQuantity = scanner.nextInt();
                        portfolio.sellStock(sellStock, sellQuantity);
                    } else {
                        System.out.println("Invalid stock symbol.");
                    }
                    break;
                case 4:
                    portfolio.displayPortfolio(market);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
